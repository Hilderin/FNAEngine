﻿using FNAEngine2D;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the game.
        /// </summary>
        [STAThread]
        static void Main()
        {
            GameManager.Run(new Scene(), GraphicSettings.Default);
        }
    }
}
