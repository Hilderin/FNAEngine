﻿using FNAEngine2D;
using Microsoft.Xna.Framework;

namespace $safeprojectname$
{
    public class Scene: GameObject
    {
        /// <summary>
        /// Load
        /// </summary>
        protected override void Load()
        {
            Add(new FPSRender());

            Add(new TextRender("Template", ContentManager.FONT_ROBOTO_REGULAR, 32, this.Game.Rectangle, Color.White, TextHorizontalAlignment.Center, TextVerticalAlignment.Middle));
        }

    }
}
